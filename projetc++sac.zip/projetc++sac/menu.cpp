#include <iostream>
#include <string>
#include "tasks.h"

int main() {
    std::string login, password;
    std::cout << "Login: "; std::getline(std::cin, login);
    std::cout << "Password: "; std::getline(std::cin, password);
    if (!connexion(login, password)) {
        std::cout << "Connexion echouee.\n";
        return 1;
    }
    std::cout << "Connexion reussie.\n";
    while (true) {
        std::cout << "\nTaches:\n";
        std::cout << "1 - Ajouter etudiant\n";
        std::cout << "2 - Rechercher etudiant\n";
        std::cout << "3 - Lister etudiants\n";
        std::cout << "4 - Quitter\n";
        std::cout << "Choix: ";
        int choix; if (!(std::cin >> choix)) break; std::cin.ignore();
        if (choix == 1) ajouter_etudiant();
        else if (choix == 2) rechercher_etudiant();
        else if (choix == 3) lister_etudiants();
        else if (choix == 4) break;
        else std::cout << "Choix invalide\n";
    }
    return 0;
}
