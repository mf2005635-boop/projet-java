#include <iostream>
#include <fstream>
#include <string>

int main(int argc, char** argv) {
    const char* ETUDIANTS_DB = "etudiants_db.txt";
    int id = 0;
    std::string nom, prenom, filiere, niveaux;

    if (argc >= 6) {
        // Usage: add_student.exe <id> <nom> <prenom> <filiere> <niveaux>
        id = std::stoi(argv[1]);
        nom = argv[2];
        prenom = argv[3];
        filiere = argv[4];
        niveaux = argv[5];
    } else {
        std::cout << "Ajout d'un etudiant (mode interactif):\n";
        std::cout << "Id: "; std::cin >> id; std::cin.ignore();
        std::cout << "Nom: "; std::getline(std::cin, nom);
        std::cout << "Prenom: "; std::getline(std::cin, prenom);
        std::cout << "Filiere: "; std::getline(std::cin, filiere);
        std::cout << "Niveaux: "; std::getline(std::cin, niveaux);
    }

    std::ofstream out(ETUDIANTS_DB, std::ios::app);
    if (!out) {
        std::cerr << "Impossible d'ouvrir le fichier " << ETUDIANTS_DB << "\n";
        return 1;
    }
    out << id << ";" << nom << ";" << prenom << ";" << filiere << ";" << niveaux << "\n";
    std::cout << "Etudiant enregistre.\n";
    return 0;
}
