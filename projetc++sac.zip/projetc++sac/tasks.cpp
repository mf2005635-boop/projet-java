#include "tasks.h"
#include "include/etudiant.h"
#include "include/secretaire.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

// Data file paths (in workspace root)
static const char *SECRETAIRES_DB = "secretaires_db.txt";
static const char *ETUDIANTS_DB = "etudiants_db.txt";

bool connexion(const std::string &login, const std::string &password) {
    std::ifstream in(SECRETAIRES_DB);
    if (!in) return false;
    std::string line;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string ids, nom, prenom, lg, pw;
        if (!std::getline(ss, ids, ';')) continue;
        if (!std::getline(ss, nom, ';')) continue;
        if (!std::getline(ss, prenom, ';')) continue;
        if (!std::getline(ss, lg, ';')) continue;
        if (!std::getline(ss, pw, ';')) continue;
        if (lg == login && pw == password) return true;
    }
    return false;
}

void ajouter_etudiant() {
    Etudiant e;
    std::cout << "Id: "; std::cin >> e.id; std::cin.ignore();
    std::cout << "Nom: "; std::getline(std::cin, e.nom);
    std::cout << "Prenom: "; std::getline(std::cin, e.prenom);
    std::cout << "Filiere: "; std::getline(std::cin, e.filiere);
    std::cout << "Niveaux: "; std::getline(std::cin, e.niveaux);

    std::ofstream out(ETUDIANTS_DB, std::ios::app);
    out << e.id << ";" << e.nom << ";" << e.prenom << ";" << e.filiere << ";" << e.niveaux << "\n";
    std::cout << "Etudiant enregistre.\n";
}

void rechercher_etudiant() {
    std::cout << "Rechercher par id (laisser vide pour chercher par nom): ";
    std::string key; std::getline(std::cin, key);
    std::ifstream in(ETUDIANTS_DB);
    if (!in) { std::cout << "Aucun etudiant enregistre.\n"; return; }
    std::string line; bool found = false;
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string id, nom, prenom, filiere, niveaux;
        std::getline(ss, id, ';');
        std::getline(ss, nom, ';');
        std::getline(ss, prenom, ';');
        std::getline(ss, filiere, ';');
        std::getline(ss, niveaux, ';');
        if (key.empty()) {
            std::cout << "Entrez nom a rechercher: ";
            std::string nomKey; std::getline(std::cin, nomKey);
            if (nom.find(nomKey) != std::string::npos) {
                std::cout << id << " | " << nom << " " << prenom << " | " << filiere << " | " << niveaux << "\n";
                found = true;
            }
        } else {
            if (id == key) {
                std::cout << id << " | " << nom << " " << prenom << " | " << filiere << " | " << niveaux << "\n";
                found = true;
            }
        }
    }
    if (!found) std::cout << "Aucun etudiant trouve.\n";
}

void lister_etudiants() {
    std::ifstream in(ETUDIANTS_DB);
    if (!in) { std::cout << "Aucun etudiant enregistre.\n"; return; }
    std::string line;
    std::cout << "Liste des etudiants:\n";
    while (std::getline(in, line)) {
        if (line.empty()) continue;
        std::stringstream ss(line);
        std::string id, nom, prenom, filiere, niveaux;
        std::getline(ss, id, ';');
        std::getline(ss, nom, ';');
        std::getline(ss, prenom, ';');
        std::getline(ss, filiere, ';');
        std::getline(ss, niveaux, ';');
        std::cout << id << " | " << nom << " " << prenom << " | " << filiere << " | " << niveaux << "\n";
    }
}
