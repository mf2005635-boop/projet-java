#include <iostream>
#include <fstream>
#include <string>

int main() {
    std::cout << "Enregistrement d'un secretaire:\n";
    int id; std::string nom, prenom, login, password;
    std::cout << "Id: "; std::cin >> id; std::cin.ignore();
    std::cout << "Nom: "; std::getline(std::cin, nom);
    std::cout << "Prenom: "; std::getline(std::cin, prenom);
    std::cout << "Login: "; std::getline(std::cin, login);
    std::cout << "Password: "; std::getline(std::cin, password);

    std::ofstream out("secretaires_db.txt", std::ios::app);
    out << id << ";" << nom << ";" << prenom << ";" << login << ";" << password << "\n";
    std::cout << "Secretaire enregistre dans secretaires_db.txt\n";
    return 0;
}
