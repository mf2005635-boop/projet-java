#ifndef SECRETAIRE_H
#define SECRETAIRE_H

#include <string>

struct Secretaire {
    int id;
    std::string nom;
    std::string prenom;
    std::string login;
    std::string password;
};

#endif // SECRETAIRE_H
