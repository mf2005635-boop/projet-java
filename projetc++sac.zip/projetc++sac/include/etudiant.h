#ifndef ETUDIANT_H
#define ETUDIANT_H

#include <string>

struct Etudiant {
    int id;
    std::string nom;
    std::string prenom;
    std::string filiere;
    std::string niveaux;
};

#endif // ETUDIANT_H
