Projet C++ minimal pour gerer etudiants et secretaires (terminal)

Fichiers crees:
- etudiant.txt : definition de la classe `Etudiant` (format .txt demande)
- secretaire.txt : definition de la classe `Secretaire` (format .txt demande)
- include/etudiant.h, include/secretaire.h : headers utilises par le code
- tasks.h / tasks.cpp : implementent `connexion`, `ajouter_etudiant`, `rechercher_etudiant`, `lister_etudiants`
- admin.cpp : programme pour enregistrer un secretaire (main)
- menu.cpp : programme principal pour se connecter et executer les taches


Compiler:
g++ -std=c++11 admin.cpp tasks.cpp -o admin.exe
g++ -std=c++11 menu.cpp tasks.cpp -o menu.exe
g++ -std=c++11 add_student.cpp -o add_student.exe

Execution:
- Enregistrer un secretaire (utiliser `admin.exe`):
  ./admin.exe
- Lancer l'interface secretaire (login/password puis menu):
  ./menu.exe
- Ajouter rapidement un etudiant (non interactif):
  ./add_student.exe <id> <nom> <prenom> <filiere> <niveaux>
  Exemple:
  ./add_student.exe 202 "Durand" "Alice" "Math" "L2"
  Si vous lancez `add_student.exe` sans arguments, il fonctionne en mode interactif.

Les donnees sont enregistrees dans `secretaires_db.txt` et `etudiants_db.txt` au format CSV separateur `;`.
