#pragma once
#include <string>

bool connexion(const std::string &login, const std::string &password);
void ajouter_etudiant();
void rechercher_etudiant();
void lister_etudiants();
